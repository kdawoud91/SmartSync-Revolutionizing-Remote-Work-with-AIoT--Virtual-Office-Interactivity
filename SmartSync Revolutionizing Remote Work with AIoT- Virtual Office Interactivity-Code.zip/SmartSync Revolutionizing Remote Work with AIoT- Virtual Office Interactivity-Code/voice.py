import os

os.system("afplay greet.mp3")

