# SmartSync: Revolutionizing Remote Work with AIoT- Virtual Office Interactivity
This is code implementation of the paper "SmartSync: Revolutionizing Remote Work with AIoT- Virtual Office Interactivity".
To run the code do the following:
1. follow the microcontroller connectivity and configuration accroding to the Arudino files
2. place your API token in main.py line 129.
3. you can replace the audio files with ones of your own to be played accordingly when actions are triggered.
4. place your attendance list in participants_list.py at roaster variable in line 12.
5. update the email list of your attendances at sendmail.py in mail_to variable at line 5.
